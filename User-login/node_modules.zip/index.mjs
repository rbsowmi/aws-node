const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { GetCommand, DynamoDBDocumentClient } = require('@aws-sdk/lib-dynamodb')
const client = new DynamoDBClient({ region: 'ap-south-1' });
const docClient = DynamoDBDocumentClient.from(client);
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const { DynamoDBClient, docClient } = require('@aws-sdk/client-dynamodb');
const { PutCommand, GetCommand } = require('@aws-sdk/lib-dynamodb')
const crypto = require('crypto');
const loginUser = async (userData) => {
    const { password, email } = userData;
    const hashedpassword = crypto.createHash('sha256').update(password).digest('hex')
    const params = {
        TableName: 'User',
        Key: { email }
    }
    try {
        const command = new GetCommand(params);
        const result = await docClient.send(command);
        if (result.Item && result.Item.password === hashedpassword) {
            return {
                statusCode: 200,
                body: JSON.stringify({ message: 'login successful' })

            }
        }
       
    }
    catch (error) {
        console.log('Error fetchind user:', error)
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'internal server error' })
        }
    }
}
export const handler = async (event) => {
    try {
        if (httpMethod === 'POST' && path === '/User/login') {
            let userData = JSON.parse(body);
            if (!userData.password || !userData.email) {
                return {
                    statusCode: 400,
                    body: JSON.stringify({ message: "email and password are required" })
                }
            }
            const res = await loginUser(userData);
            console.log(res);
            return res;
        }
        return {
            statusCode: 404,
            body: JSON.stringify({ message: "users not exist" })
        }
    }
    catch (error) {
        console.log(error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Internal Server Error'
            })
        }
    }
}
